package com.leejoonhee.lookup;

import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.Timer;
import java.util.TimerTask;

public class ClipBoardService extends Service implements ClipboardManager.OnPrimaryClipChangedListener {

    ClipboardManager mManager;
    Timer timer = new Timer();
    String clip;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }


    @Override
    public void onCreate() {
        Log.i("ClipBoard", "ServiceStarted");
        super.onCreate();

        mManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        mManager.addPrimaryClipChangedListener(this);

        TimerTask TT = new TimerTask() {
            @Override
            public void run() { }
        };

        timer.schedule(TT, 0, 1000); //Timer 실행
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // 리스너 해제
        mManager.removePrimaryClipChangedListener(this);
    }

    @Override
    public void onPrimaryClipChanged() {

        if (mManager != null && mManager.getPrimaryClip() != null) {
            ClipData data = mManager.getPrimaryClip();

            // 한번의 복사로 복수 데이터를 넣었을 수 있으므로, 모든 데이터를 가져온다.
            int dataCount = data.getItemCount();
            for (int i = 0 ; i < dataCount ; i++) {
                //Log.i("CLipBoardService", "clip data changed : " + data.getItemAt(i).coerceToText(this));
                lookup((String) data.getItemAt(i).coerceToText(this));

            }
        }
        else {
            Log.w("Alart", "No Manager or No Clip data");
        }

    }

    public void lookup(String clipboard){
        Log.i("ClipBoardService", clipboard);
    }
}
